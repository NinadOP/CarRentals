document.getElementById('bookingForm').addEventListener('submit', function(e) {
  e.preventDefault();
  alert("Your booking has been submitted!");
});
